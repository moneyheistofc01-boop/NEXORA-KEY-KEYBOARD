plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// GitHub Actions passes -PbuildNumber=<run number>; every build gets a higher versionCode.
val buildNumber: Int = (project.findProperty("buildNumber") as String?)?.toIntOrNull() ?: 3

android {
    namespace = "com.ntech.nexorakey"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.ntech.nexorakey"
        minSdk = 24
        targetSdk = 34
        versionCode = buildNumber
        versionName = "0.3.$buildNumber"
    }

    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
