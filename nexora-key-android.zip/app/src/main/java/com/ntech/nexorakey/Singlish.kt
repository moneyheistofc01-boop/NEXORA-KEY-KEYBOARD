package com.ntech.nexorakey

/** Latin ("Singlish") -> Sinhala transliteration with alternative suggestions. */
object Singlish {
    private class V(val lat: String, val ind: String, val sign: String)

    private val vowels: List<V> = listOf(
        V("aa", "\u0D86", "\u0DCF"), V("ae", "\u0D87", "\u0DD0"), V("AA", "\u0D88", "\u0DD1"),
        V("ii", "\u0D8A", "\u0DD3"), V("ee", "\u0D92", "\u0DDA"), V("uu", "\u0D8C", "\u0DD6"),
        V("oo", "\u0D95", "\u0DDD"), V("ai", "\u0D93", "\u0DDB"), V("au", "\u0D96", "\u0DDE"),
        V("a", "\u0D85", ""), V("A", "\u0D87", "\u0DD0"), V("i", "\u0D89", "\u0DD2"),
        V("u", "\u0D8B", "\u0DD4"), V("e", "\u0D91", "\u0DD9"), V("o", "\u0D94", "\u0DDC"),
        V("I", "\u0D8A", "\u0DD3"), V("E", "\u0D92", "\u0DDA"), V("O", "\u0D95", "\u0DDD"),
        V("U", "\u0D8C", "\u0DD6")
    ).sortedByDescending { it.lat.length }

    private val consonants: List<Pair<String, String>> = listOf(
        "nk" to "\u0D82\u0D9A", "nh" to "\u0D82\u0DC4", "ng" to "\u0D82\u0D9C",
        "kh" to "\u0D9B", "gh" to "\u0D9D", "chh" to "\u0DA1", "ch" to "\u0DA0",
        "jh" to "\u0DA3", "ny" to "\u0DA4", "Th" to "\u0DA8", "Dh" to "\u0DAA",
        "thh" to "\u0DAE", "dhh" to "\u0DB0", "th" to "\u0DAD", "dh" to "\u0DAF",
        "ph" to "\u0DB5", "bh" to "\u0DB7", "sh" to "\u0DC1", "Sh" to "\u0DC2",
        "gn" to "\u0DA5", "\u0001" to "\u0DB3", "\u0002" to "\u0DB9", "\u0003" to "\u0D9F",
        "k" to "\u0D9A", "g" to "\u0D9C", "c" to "\u0DA0", "j" to "\u0DA2",
        "T" to "\u0DA7", "D" to "\u0DA9", "N" to "\u0DAB", "t" to "\u0DAD",
        "d" to "\u0DAF", "n" to "\u0DB1", "p" to "\u0DB4", "b" to "\u0DB6",
        "m" to "\u0DB8", "y" to "\u0DBA", "r" to "\u0DBB", "l" to "\u0DBD",
        "v" to "\u0DC0", "w" to "\u0DC0", "s" to "\u0DC3", "h" to "\u0DC4",
        "L" to "\u0DC5", "f" to "\u0DC6", "S" to "\u0DC1", "K" to "\u0D9B",
        "G" to "\u0D9D", "C" to "\u0DA1", "J" to "\u0DA3", "B" to "\u0DB7",
        "P" to "\u0DB5", "z" to "\u0DC3", "q" to "\u0D9A",
        "M" to "\u0DB8", "R" to "\u0DBB", "Y" to "\u0DBA", "V" to "\u0DC0",
        "W" to "\u0DC0", "Z" to "\u0DC3", "F" to "\u0DC6", "Q" to "\u0D9A"
    ).sortedByDescending { it.first.length }

    private fun matchVowel(s: String, i: Int): V? {
        for (v in vowels) if (s.startsWith(v.lat, i)) return v
        return null
    }

    private fun matchCons(s: String, i: Int): Pair<String, String>? {
        for (c in consonants) if (s.startsWith(c.first, i)) return c
        return null
    }

    fun convert(s: String): String {
        val out = StringBuilder()
        var pending = false
        var i = 0
        while (i < s.length) {
            val v = matchVowel(s, i)
            if (v != null) {
                if (pending) {
                    out.append(v.sign)
                    pending = false
                } else {
                    out.append(v.ind)
                }
                i += v.lat.length
                continue
            }
            val c = matchCons(s, i)
            if (c != null) {
                val isRY = c.first == "r" || c.first == "y"
                if (pending && isRY && i + 1 < s.length && matchVowel(s, i + 1) != null) {
                    // rakaransaya / yansaya: consonant + HAL + ZWJ + RA|YA
                    out.append("\u0DCA\u200D").append(c.second)
                } else {
                    if (pending) out.append("\u0DCA")
                    out.append(c.second)
                    pending = true
                }
                i += c.first.length
                continue
            }
            val ch = s[i]
            when (ch) {
                'x' -> {
                    out.append("\u0D82")
                    pending = false
                }
                'H' -> {
                    out.append("\u0D83")
                    pending = false
                }
                else -> {
                    if (pending) {
                        out.append("\u0DCA")
                        pending = false
                    }
                    out.append(ch)
                }
            }
            i++
        }
        if (pending) out.append("\u0DCA")
        return out.toString()
    }

    /** First item is the default conversion, the rest are common alternatives. */
    fun suggestions(s: String): List<String> {
        val set = LinkedHashSet<String>()
        set.add(convert(s))
        for (alt in variants(s)) {
            set.add(convert(alt))
            if (set.size >= 7) break
        }
        return set.toList()
    }

    private fun variants(s: String): List<String> {
        val res = ArrayList<String>()
        for (i in s.indices) {
            val c = s[i]
            val next = if (i + 1 < s.length) s[i + 1] else ' '
            val rep = { len: Int, alt: String -> res.add(s.substring(0, i) + alt + s.substring(i + len)) }
            when {
                s.startsWith("nd", i) -> rep(2, "\u0001")
                s.startsWith("mb", i) -> rep(2, "\u0002")
                s.startsWith("ng", i) -> rep(2, "\u0003")
                s.startsWith("sh", i) -> rep(2, "Sh")
                s.startsWith("Sh", i) -> rep(2, "sh")
                c == 's' && next != 'h' -> rep(1, "sh")
                c == 't' && next != 'h' -> rep(1, "T")
                c == 'T' && next != 'h' -> rep(1, "t")
                c == 'd' && next != 'h' -> rep(1, "D")
                c == 'D' && next != 'h' -> rep(1, "d")
                c == 'n' && next != 'g' && next != 'y' && next != 'k' && next != 'h' -> rep(1, "N")
                c == 'N' -> rep(1, "n")
                c == 'l' -> rep(1, "L")
                c == 'L' -> rep(1, "l")
            }
        }
        return res
    }
}
