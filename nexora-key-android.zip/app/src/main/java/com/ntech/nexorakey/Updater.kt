package com.ntech.nexorakey

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.os.Build
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** In-app updater: reads the latest GitHub Release and installs its APK. Only runs when the user taps the button. */
object Updater {
    const val REPO = "moneyheistofc01-boop/NEXORA-KEY-KEYBOARD"

    class Info(val build: Int, val url: String)

    private fun open(url: String, accept: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 30000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "NEXORA-KEY-Updater")
        c.setRequestProperty("Accept", accept)
        return c
    }

    /** Returns the newest release, or null when nothing usable was found. */
    fun check(): Info? {
        val c = open("https://api.github.com/repos/$REPO/releases/latest", "application/vnd.github+json")
        try {
            val code = c.responseCode
            if (code == 404) throw Exception("Release \u0D91\u0D9A\u0D9A\u0DCA \u0DC3\u0DDC\u0DBA\u0DCF\u0D9C\u0DAD \u0DB1\u0DDC\u0DC4\u0DD0\u0D9A (repo \u0D91\u0D9A Public \u0DAF?)")
            if (code != 200) throw Exception("HTTP $code")
            val text = c.inputStream.bufferedReader().use { it.readText() }
            val j = JSONObject(text)
            val tag = j.getString("tag_name")
            val build = tag.filter { it.isDigit() }.toIntOrNull() ?: return null
            val assets = j.getJSONArray("assets")
            for (i in 0 until assets.length()) {
                val a = assets.getJSONObject(i)
                if (a.getString("name").endsWith(".apk")) {
                    return Info(build, a.getString("browser_download_url"))
                }
            }
            return null
        } finally {
            c.disconnect()
        }
    }

    fun download(ctx: Context, url: String, onProgress: (Int) -> Unit): File {
        val out = File(ctx.cacheDir, "update.apk")
        val c = open(url, "application/octet-stream")
        try {
            if (c.responseCode != 200) throw Exception("HTTP ${c.responseCode}")
            val total = c.contentLengthLong
            var done = 0L
            var last = -1
            c.inputStream.use { input ->
                out.outputStream().use { o ->
                    val buf = ByteArray(32 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        o.write(buf, 0, n)
                        done += n
                        if (total > 0) {
                            val p = (done * 100 / total).toInt()
                            if (p != last && p % 5 == 0) {
                                last = p
                                onProgress(p)
                            }
                        }
                    }
                }
            }
        } finally {
            c.disconnect()
        }
        return out
    }

    fun install(ctx: Context, file: File) {
        val installer = ctx.packageManager.packageInstaller
        val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
        val id = installer.createSession(params)
        val session = installer.openSession(id)
        try {
            file.inputStream().use { input ->
                session.openWrite("nexora-key.apk", 0, file.length()).use { o ->
                    input.copyTo(o)
                    session.fsync(o)
                }
            }
            val intent = Intent(ctx, InstallReceiver::class.java)
            intent.action = InstallReceiver.ACTION
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
            val pending = PendingIntent.getBroadcast(ctx, id, intent, flags)
            session.commit(pending.intentSender)
        } finally {
            session.close()
        }
    }
}
