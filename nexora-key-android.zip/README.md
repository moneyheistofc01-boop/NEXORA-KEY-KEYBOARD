# NEXORA KEY — by N TECH OFC

Native Android keyboard project (Kotlin / `InputMethodService`). The app's setup UI is in English; keyboard input layouts include English, Singlish, Sinhala and Arabic.

## Build automatically on GitHub

1. Upload/commit this entire project to `moneyheistofc01-boop/NEXORA-KEY-KEYBOARD` on the `main` branch. Keep `.github/workflows/android-release.yml` in that exact path.
2. In GitHub, open **Settings → Actions → General → Workflow permissions** and ensure workflows can write repository contents (or retain the workflow's `contents: write` permission if repository policy allows it).
3. Open **Actions → Build and publish NEXORA KEY** and wait for the run to finish green. Each push to `main` builds the APK and publishes it to GitHub Releases.
4. Install the APK once. Later, open NEXORA KEY → **App Updates** → **Check for update** → **Download & Install**. Android may ask you to allow installs from NEXORA KEY and will always ask for confirmation before installing.

## Important update notes

- The in-app updater checks the latest **public GitHub Release** for this repository. A first release must exist before it can find an update.
- This is an opt-in update flow; it does not silently install APKs. Android requires user approval.
- The current project is a functional starter keyboard, not a complete feature-for-feature clone of Flash Board. Features such as cloud AI, online translation, voice typing, sticker stores, advanced prediction and clipboard history need their own implementations and permissions/services.
- Do not commit signing keys, API tokens, passwords or other secrets to the repository.

## Local build

With Android SDK and Gradle 8.7 installed:

```bash
gradle assembleDebug -PbuildNumber=3
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.
